package aic.bigdata.server;

import org.eclipse.jetty.servlet.DefaultServlet;


public class MainServerServlet extends DefaultServlet{

}
