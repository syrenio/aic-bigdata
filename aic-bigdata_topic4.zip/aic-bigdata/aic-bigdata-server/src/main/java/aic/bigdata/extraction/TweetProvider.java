package aic.bigdata.extraction;

public interface TweetProvider extends Runnable{
	
	public void addTweetHandler(TweetHandler t);
	
	public void stopProvider();

}
