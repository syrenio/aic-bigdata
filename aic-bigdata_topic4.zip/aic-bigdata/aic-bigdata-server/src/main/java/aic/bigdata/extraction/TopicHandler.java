package aic.bigdata.extraction;

import java.net.UnknownHostException;

public interface TopicHandler {
	public void HandleTopic(String topic) throws UnknownHostException;
}
